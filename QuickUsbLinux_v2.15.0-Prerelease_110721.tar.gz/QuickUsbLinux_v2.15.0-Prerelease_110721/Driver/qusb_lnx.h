/*=============================================================================

Title        : qusb_lnx.h
Description  : QuickUSB Linux Driver Header
Notes        : None
History      :

Copyright  2010 Bitwise Systems.  All rights reserved.
This software contains confidential information and trade secrets of
Bitwise Systems and is protected by United States and international
copyright laws.  Use, disclosure, or reproduction is prohibited without
the prior express written permission of Bitwise Systems, except as agreed
in the QuickUSB Plug-In Module license agreement.

Use, duplication or disclosure by the U.S. Government is subject to
restrictions as provided in DFARS 227.7202-1(a) and 227.7202-3(a)
(1998), and FAR 12.212, as applicable.  Bitwise Systems, 6489 Calle Real, 
Suite E, Goleta, CA  93117.

Bitwise Systems
6489 Calle Real, Suite E
Goleta, CA  93117
Voice: (805) 683-6469
Fax  : (805) 683-4833
Web  : www.bitwisesys.com
email: support@bitwisesys.com

=============================================================================*/
#include <asm/errno.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include <linux/fs.h>
#include <linux/highmem.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/kref.h>
#include <linux/mm.h>
#include <linux/module.h>
#include <linux/pagemap.h>
#include <linux/slab.h>
#include <linux/smp_lock.h>
#include <linux/time.h>
#include <linux/usb.h>
#include <linux/version.h>
#include <linux/types.h>
//#include <linux/compat.h>


typedef int             BOOL;
typedef int             BOOLEAN;
typedef unsigned char   BYTE, CHAR, UCHAR;
typedef unsigned char * PUCHAR;
typedef signed long     LONG;
typedef unsigned long   ULONG, DWORD;
typedef unsigned short  USHORT, WCHAR, WORD;
typedef void *          PVOID;


#include "Version.h"
//#include "../../../Software/QuickUSB/QuickUsbVersion.h"
#include "ioctl.h"

// Macros
//#define DEBUG
#define VENDOR_ID 0x0fbb
#define PRODUCT_ID 0x0001
#define DRIVER_NAME "qusb"
#define MINOR_BASE 0xAB

#define QUSB_DEFAULT_TIMEOUT 1000

#define QUSB_EP_BULK_IN  0x86
#define QUSB_EP_BULK_OUT 0x02

//#define MAX_STRING_LENGTH 128
#define MAX_DATA_LENGTH 64

//#define MAX_ASYNC_RW 253

#define FALSE                 0
#define TRUE                  1

//#define MAX_MMAP_SIZE (256 * 1024)
#define QUSB_MAX_KMALLOC_SIZE (128 * 1024)
#define QUSB_MAX_MMAP_SIZE (QUSB_MAX_KMALLOC_SIZE - (2 * PAGE_SIZE))

// Print macros
#ifdef DEBUG
#define QUSB_PRINTK(a)    printk a
#else
#define QUSB_PRINTK(a)
#endif

//#if !defined(compat_ptr)
//#ifndef compat_ptr
//asdf
//#define compat_ptr(x) ((void __user *)(x))
//#endif
static inline void __user *compat_ptr(u32 uptr);

//
// Driver error status, returned from IOCTL_QUSB_GET_LAST_ERROR.  This
// replaces NTSTATUS codes which are undefined in the DLL.  These values
// are stored in the DEVICE EXTENSION DriverStatus member.
//
enum
{
   DriverErrorNone               = 0x0000,
   DriverErrorInvalidParameter   = 0x0001,
   DriverErrorMemory             = 0x0002,
   DriverErrorURB                = 0x0003,
   DriverErrorTimeout            = 0x0004,
   DriverErrorBulk               = 0x0005,
   DriverErrorAsync              = 0x0006,
   DriverErrorPipe               = 0x0007,
   DriverErrorBusy               = 0x0008
};



// QuickUSB Device struct.  Each connected module gets an instance
// of this struct whose pointer is stored in the private data of
// the file descriptor (struct file *filp)
struct qusb_dev {
    struct usb_device *udev;
    struct usb_interface *interface;
    struct urb *ctrl_urb;
    struct usb_ctrlrequest ctrl_request;
    unsigned char * bulk_in_buffer;
    size_t bulk_in_length;
    __u8 bulk_in_address;
    __u8 bulk_out_address;
    int *buffer_ptr;
    int *buffer_area;
    //int *async_buffer_ptr[MAX_ASYNC_RW];
    //int *async_buffer_area[MAX_ASYNC_RW];
    //int async_buffer_count;
    int timeout;
    struct kref ref;
};



// Never called by library -- used internally in driver only
static int qusb_probe(struct usb_interface *interface, const struct usb_device_id *device_id);
static int qusb_open(struct inode *inode, struct file *filp);
static int qusb_release(struct inode *inode, struct file *filp);
#if defined(HAVE_UNLOCKED_IOCTL)
static long qusb_unlocked_ioctl(struct file *filp, unsigned int cmd, unsigned long arg);
#else
static long qusb_locked_ioctl(struct inode *inode, struct file *filp, unsigned int cmd, unsigned long arg);
#endif
static int qusb_ioctl(struct file *filp, unsigned int cmd, void __user *arg, BYTE compat);
#if defined(HAVE_COMPAT_IOCTL)
static long qusb_compat_ioctl(struct file *filp, unsigned int cmd, unsigned long arg);
#endif
static ssize_t qusb_read(struct file *filp, char __user *buf, size_t length, loff_t *ppos);
static ssize_t qusb_write(struct file *filp, const char __user *buf, size_t length, loff_t *ppos);
//static int qusb_mmap(struct file *filp, struct vm_area_struct *vma);
static void qusb_disconnect(struct usb_interface *interface);
static void qusb_delete(struct kref *kref);
//static void qusb_read_bulk_callback(struct urb *urb);
//static void qusb_write_bulk_callback(struct urb *urb);

// Called (indirectly through IOCTL) by library
long Qusb_GetStringDescriptor(struct file *filp, UCHAR index, PVOID buffer, ULONG length);
long Qusb_GetDeviceDescriptor(struct file *filp, struct usb_device_descriptor *device_descriptor);
long Qusb_VendorRequest(struct file *filp, QUSB_VENDOR_OR_CLASS_REQUEST_CONTROL *vcrc, BYTE compat);
//long Qusb_ReadWriteBulk(struct file *filp, UCHAR dir, struct QUSB_BULK_TRANSFER_CONTROL *bulk_control);
//long Qusb_ReadWriteBulkAsync(struct file *filp, UCHAR dir, struct QUSB_BULK_TRANSFER_CONTROL *bulk_control);
