/*=============================================================================
Title        : qusb_lnx.c
Description  : QuickUSB Linux Driver
Notes        : None
History      :

Copyright  2010 Bitwise Systems.  All rights reserved.
This software contains confidential information and trade secrets of
Bitwise Systems and is protected by United States and international
copyright laws.  Use, disclosure, or reproduction is prohibited without
the prior express written permission of Bitwise Systems, except as agreed
in the QuickUSB Plug-In Module license agreement.

Use, duplication or disclosure by the U.S. Government is subject to
restrictions as provided in DFARS 227.7202-1(a) and 227.7202-3(a)
(1998), and FAR 12.212, as applicable.  Bitwise Systems, 6489 Calle Real, 
Suite E, Goleta, CA  93117.

Bitwise Systems
6489 Calle Real, Suite E
Goleta, CA  93117
Voice: (805) 683-6469
Fax  : (805) 683-4833
Web  : www.bitwisesys.com
email: support@bitwisesys.com

=============================================================================*/
#include "qusb_lnx.h"

// QuickUSB SLA
MODULE_LICENSE("GPL");

static inline void __user *compat_ptr(u32/*compat_uptr_t*/ uptr) {
    return (void __user *)(unsigned long)uptr;
}

// Globals
static struct usb_device_id qusb_devtable [] = {
    { USB_DEVICE(VENDOR_ID, PRODUCT_ID) },
    {}
};
MODULE_DEVICE_TABLE(usb, qusb_devtable);

static struct file_operations qusb_fops = {
    .owner = THIS_MODULE,
    .open = qusb_open,
    .release = qusb_release,
#if defined(HAVE_UNLOCKED_IOCTL)
	.unlocked_ioctl = qusb_unlocked_ioctl,
#if defined(HAVE_COMPAT_IOCTL)
	.compat_ioctl = qusb_compat_ioctl,
#endif	
#else
    .ioctl = qusb_locked_ioctl, // No longer defined in 2.6.36 kernels and later
#endif
    .read = qusb_read,
    .write = qusb_write,
    //.mmap = qusb_mmap,
};

static struct usb_driver qusb_driver = {
    .name = DRIVER_NAME,
    .id_table = qusb_devtable,
    .probe = qusb_probe,
    .disconnect = qusb_disconnect,
};

static struct usb_class_driver qusb_class = {
    .name = "QUSB-%d", // This creates the entry in /dev
    .fops = &qusb_fops,
    .minor_base = MINOR_BASE,
};

static int num_qusb;

static QUSB_GET_DRIVER_ERROR driver_error;

// Callback used for async ops
//DECLARE_COMPLETION(qusb_complete);



// Get string descriptors
long Qusb_GetStringDescriptor(struct file *filp, UCHAR index, PVOID buffer, ULONG length) {
    struct qusb_dev *dev;
    int result, k;
    
    QUSB_PRINTK(("Retrieving String #%d, length=%d\n", (int)index, (int)length));

    // Get QuickUSB device
    dev = filp->private_data;
    if (dev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid QuickUSB device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
    if (dev->udev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
    
    // Check buffer
    if (buffer == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid buffer.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
    
    // Retrieve string descriptor
    result = usb_control_msg(dev->udev,        // Device
            usb_rcvctrlpipe(dev->udev, 0),    // Pipe
            USB_REQ_GET_DESCRIPTOR,        // Request
            USB_DIR_IN,            // Request type
            (USB_DT_STRING<<8)|index,    // Value
            0,                // Index
            buffer,                // Data
            MAX_STRING_DESCRIPTOR_OUT_LENGTH,        // Size
            dev->timeout);            // Timeout

    if (result == -ETIMEDOUT) {
        driver_error.DriverError = DriverErrorTimeout;
    }

    if (result >= 0) {
        QUSB_PRINTK(("String Desc #%d: ", (int)index));
        for (k=2; k<length && ((char *)buffer)[k] != 0; k+=2) {
            QUSB_PRINTK(("%c", ((char *)buffer)[k]));
        }
        QUSB_PRINTK(("\n"));
    } else {
        QUSB_PRINTK(("String Desc#%d: Failed with error 0x%X", (int)index, result));
    }
    
    return result;
}



// Get the USB device desc info
long Qusb_GetDeviceDescriptor(struct file *filp, struct usb_device_descriptor *device_descriptor) {
    struct qusb_dev *dev;
    int result;
    
    // Get QuickUSB device
    dev = filp->private_data;
    if (dev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid QuickUSB device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
    if (dev->udev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
    if (device_descriptor == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid device descriptor.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
    
    // Retrieve device descriptor
    result = usb_control_msg(dev->udev,                // Device
            usb_rcvctrlpipe(dev->udev, 0),            // Pipe
            USB_REQ_GET_DESCRIPTOR,                    // Request
            USB_DIR_IN,                             // Request type
            (USB_DT_DEVICE<<8),                        // Value
            0,                                        // Index
            device_descriptor,                        // Data
            sizeof(struct usb_device_descriptor),    // Size
            dev->timeout);                            // Timeout
    if (result == -ETIMEDOUT) {
        driver_error.DriverError = DriverErrorTimeout;
    }
    
    return result;
}



// Perform vendor requests (control requests)
long Qusb_VendorRequest(struct file *filp, QUSB_VENDOR_OR_CLASS_REQUEST_CONTROL *vcrc, BYTE compat) {
    struct qusb_dev *dev;
#ifdef DEBUG
    struct timeval tv[2];
#endif
    dma_addr_t dma;
    UCHAR requestType;
    unsigned int ctrl_pipe;
    void *buffer;
    ULONG length;
    int result, k;
    
    buffer = NULL;
    
    // Get QuickUSB device
    dev = filp->private_data;
    if (dev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid QuickUSB device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
    if (dev->udev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
   
    // Check request control
    if (vcrc == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid request control.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }

    // Get request type and length
    requestType = (vcrc->direction<<7)|(vcrc->requestType<<5)|(vcrc->recepient); 
    // Allocate buffer memory
    length = vcrc->length;
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,34)
    buffer = usb_buffer_alloc(dev->udev, length, GFP_KERNEL, &dma);
#else
    buffer = usb_alloc_coherent(dev->udev, length, GFP_KERNEL, &dma);
#endif
    if (buffer == NULL) {
		QUSB_PRINTK(("Unable to allocate memory (Device=0x%p, Len=%li)\n", dev->udev, length));
        driver_error.DriverError = DriverErrorMemory;
        return -ENOMEM;
    }
    
    // Get control pipe
    if (vcrc->direction == 0) { // Out
        ctrl_pipe = usb_sndctrlpipe(dev->udev, 0);
        
        // Copy data from user space to write
//#if defined(HAVE_COMPAT_IOCTL)
        if ((compat && copy_from_user(buffer, compat_ptr((ULONG)vcrc->data), length)) ||
			(!compat && copy_from_user(buffer, vcrc->data, length))) {
//#else
//	if (copy_from_user(buffer, vcrc->data, length)) {
//#endif
			QUSB_PRINTK(("QuickUSB: Unable to copy data from user land\n"));
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,34)
            usb_buffer_free(dev->udev, length, buffer, dma);
#else
            usb_free_coherent(dev->udev, length, buffer, dma);
#endif
            driver_error.DriverError = DriverErrorMemory;
            return -EFAULT;
        }

        for (k=0; k<length; ++k) {
            QUSB_PRINTK(("QuickUSB data[%i]: 0x%x\n", k, ((unsigned char *)buffer)[k]));
        }
    
    }
    else if (vcrc->direction == 1) { // In
        ctrl_pipe = usb_rcvctrlpipe(dev->udev, 0);
    }
    else {
        QUSB_PRINTK(("QuickUSB Error: Invalid direction.\n"));
        driver_error.DriverError = DriverErrorPipe;
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,34)
        usb_buffer_free( dev->udev, length, buffer, dma );
#else
        usb_free_coherent( dev->udev, length, buffer, dma );
#endif
        return -1;
    }
    
    // Submit vendor request
#ifdef DEBUG
    do_gettimeofday(&tv[0]);
#endif
    QUSB_PRINTK(("QuickUSB: vcrc->request=%x\n", vcrc->request));
    QUSB_PRINTK(("QuickUSB: requestType=%i\n", requestType));
    QUSB_PRINTK(("QuickUSB: vcrc->value=%i\n", vcrc->value));
    QUSB_PRINTK(("QuickUSB: vcrc->index=%i\n", vcrc->index));
    QUSB_PRINTK(("QuickUSB: length=%li\n", length));
    result = usb_control_msg(dev->udev,    // Device
            ctrl_pipe,                    // Pipe
            vcrc->request,                // Request
            requestType,                // Request type
            vcrc->value,                // Value
            vcrc->index,                // Index
            buffer,                        // Data
            length,                        // Size
            dev->timeout);                // Timeout
    QUSB_PRINTK(("QuickUSB: result=%i\n", result));
#ifdef DEBUG
    do_gettimeofday(&tv[1]);
    QUSB_PRINTK(("QuickUSB: Vendor request elapsed time: %lu\n", (ULONG)(tv[1].tv_sec-tv[0].tv_sec)*1000000+(ULONG)(tv[1].tv_usec-tv[0].tv_usec)));
#endif
    if (result >= 0) {
        // Copy data to user space
        if (vcrc->direction == 1) { // In
//#if defined(HAVE_COMPAT_IOCTL)
            if ((compat && copy_to_user(compat_ptr((ULONG)vcrc->data), buffer, length)) ||
				(!compat && copy_to_user(vcrc->data, buffer, length))) {
//#else
//	    if (copy_to_user(vcrc->data, buffer, length)) {
//#endif
				QUSB_PRINTK(("QuickUSB: Unable to copy data back to user land"));
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,34)
                usb_buffer_free(dev->udev, length, buffer, dma);
#else
                usb_free_coherent(dev->udev, length, buffer, dma);
#endif
                return -EFAULT;
            }
        }
        
        vcrc->length = result;
    }
    else {
        if (result == -ETIMEDOUT) {
            driver_error.DriverError = DriverErrorTimeout;
        }
        else {
            driver_error.DriverError = DriverErrorURB;
        }
        vcrc->length = 0;
    }
    
    // Free allocated memory
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,34)
    usb_buffer_free(dev->udev, length, buffer, dma);
#else
    usb_free_coherent(dev->udev, length, buffer, dma);
#endif
    
    return result;
}



// Bulk reads and writes
long Qusb_ReadWriteBulk(struct file *filp, UCHAR dir, QUSB_BULK_TRANSFER_CONTROL *bulk_control) {
    struct qusb_dev *dev;
#ifdef DEBUG
    struct timeval tv[2];
#endif
    unsigned int bulk_pipe;
    int actual_length;
    int result;//, k;
    unsigned char *pData;
    
    dev = NULL;    
    actual_length = 0;
    result = 0;
    
    // Get QuickUSB device
    dev = filp->private_data;
    if (dev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid QuickUSB device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
    if (dev->udev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
    
    // Check bulk control
    if (bulk_control == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid bulk control.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
    
    // Get bulk pipe
    if (dir == 0) { // Out
        bulk_pipe = usb_sndbulkpipe(dev->udev, dev->bulk_out_address);
        QUSB_PRINTK(("Bulk Out Adr: %d", (int)dev->bulk_out_address));
    }
    else if ( dir == 1 ) { // In
        bulk_pipe = usb_rcvbulkpipe(dev->udev, dev->bulk_in_address);
    }
    else {
        QUSB_PRINTK(("QuickUSB Error: Invalid direction.\n"));
        driver_error.DriverError = DriverErrorPipe;
        return -1;
    }
    
    // Submit bulk request
#ifdef DEBUG
    do_gettimeofday(&tv[0]);
#endif
    QUSB_PRINTK(("Writing %d bytes\n", (int)bulk_control->length));
    result = usb_bulk_msg(dev->udev,    // Device
            bulk_pipe,                    // Pipe
            dev->buffer_area,            // Kernel space address
            bulk_control->length,        // Length
            &actual_length,                // Actual length
            dev->timeout);                // Timeout

    pData = (unsigned char *)dev->buffer_area;
    //for (k=0; k<actual_length; ++k) {
    //    QUSB_PRINTK(("Bulk data[%d]=%#x\n", k, pData[k]));
    //}
#ifdef DEBUG
    do_gettimeofday(&tv[1]);
    QUSB_PRINTK(("QuickUSB: Bulk transfer elapsed time: %lu\n", (ULONG)(tv[1].tv_sec-tv[0].tv_sec)*1000000+(ULONG)(tv[1].tv_usec-tv[0].tv_usec)));
#endif
    if (result < 0) {
        if (result == -ETIMEDOUT) {
            QUSB_PRINTK(("QuickUSB Error: Timeout (%d).\n", result));
            driver_error.DriverError = DriverErrorTimeout;
        }
        else {
            QUSB_PRINTK(("QuickUSB Error: Bulk request failed with %d.\n", result));
            driver_error.DriverError = DriverErrorBulk;
        }
    }
    
    // Store bytes written/read in bulk control
    bulk_control->length = actual_length;
    
    return result;
}



// Note: Qusb_ReadWriteBulkAsync() has not been fully implemented nor tested.
/*long Qusb_ReadWriteBulkAsync(struct file *filp, UCHAR dir, QUSB_BULK_TRANSFER_CONTROL *bulk_control) {
    struct qusb_dev *dev;
#ifdef DEBUG
    struct timeval tv[2];
#endif
    struct urb *urb;
    unsigned int bulk_pipe;
    int result;
    
    // Get QuickUSB device
    dev = filp->private_data;
    if (dev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid QuickUSB device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
    if (dev->udev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
    
    // Check bulk control
    if (bulk_control == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid bulk control.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -1;
    }
    
    // Get bulk pipe
    if (dir == 0) { // Out
        bulk_pipe = usb_sndbulkpipe(dev->udev, dev->bulk_out_address);
    }
    else if (dir == 1) { // In
        bulk_pipe = usb_rcvbulkpipe(dev->udev, dev->bulk_in_address);
    }
    else {
        QUSB_PRINTK(("QuickUSB Error: Invalid direction.\n"));
        driver_error.DriverError = DriverErrorPipe;
        return -1;
    }

    // Allocate urb
    urb = usb_alloc_urb(0, GFP_KERNEL);
    if (!urb) {
        driver_error.DriverError = DriverErrorMemory;
        return -ENOMEM;
    }
    
    // Fill urb
    if (dir == 0) { // Out
        usb_fill_bulk_urb(urb,                        // Urb
                dev->udev,                    // Device
                bulk_pipe,                    // Pipe
                dev->buffer_area,                // Data
                bulk_control->Length,                // Length
                (usb_complete_t)&qusb_write_bulk_callback,    // Completion callback
                dev);                        // Context
    }
    else { // In
        usb_fill_bulk_urb(urb,                        // Urb
                dev->udev,                    // Device
                bulk_pipe,                    // Pipe
                dev->buffer_area,                // Data
                bulk_control->Length,                // Length
                (usb_complete_t)&qusb_read_bulk_callback,    // Completion callback
                dev);                        // Context
    }

    // Submit bulk urb
#ifdef DEBUG
    do_gettimeofday(&tv[0]);
#endif
    result = usb_submit_urb(urb, GFP_KERNEL);
#ifdef DEBUG
    do_gettimeofday(&tv[1]);
    QUSB_PRINTK(("QuickUSB: Async urb submit elapsed time: %lu\n", (ULONG)(tv[1].tv_sec-tv[0].tv_sec)*1000000+(ULONG)(tv[1].tv_usec-tv[0].tv_usec)));
#endif
    if (result < 0) {
        QUSB_PRINTK(("QuickUSB Error: Async bulk request failed with %d.\n", result));
        if (result == ETIMEDOUT) {
            driver_error.DriverError = DriverErrorTimeout;
        }
        else {
            driver_error.DriverError = DriverErrorAsync;
        }
    }
    
    // Wait for completion
#ifdef DEBUG
    do_gettimeofday(&tv[0]);
#endif
    wait_for_completion_timeout(&qusb_complete, dev->timeout/1000*HZ);
#ifdef DEBUG
    do_gettimeofday(&tv[1]);
    QUSB_PRINTK(("QuickUSB: Async transfer elapsed time: %lu\n", (ULONG)(tv[1].tv_sec-tv[0].tv_sec)*1000000+(ULONG)(tv[1].tv_usec-tv[0].tv_usec)));
#endif

    complete(&qusb_complete);
    
    // Free allocated urb
    usb_free_urb(urb);
   
    return result;
}*/



// Called once when the driver is first inserted to probe for any connected modules
// Also intializes the endpoints.  What initializes the endpoints when a module is 
// attached after the driver is inserted?  Good question.
static int qusb_probe(struct usb_interface *interface, const struct usb_device_id *device_id) {
    struct qusb_dev *dev;
    struct usb_host_interface *iface_desc;
    struct usb_endpoint_descriptor *endpoint;
    int result, i;
    
    // Allocate space for QuickUSB device
    dev = kmalloc(sizeof(struct qusb_dev), GFP_KERNEL);
    if (dev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Out of memory.\n"));
        return -ENOMEM;
    }
    memset(dev, 0x00, sizeof(struct qusb_dev));
    
    // Initialize QuickUSB device
    dev->udev = usb_get_dev(interface_to_usbdev(interface));
    dev->interface = interface;
    kref_init(&dev->ref);
   
    // Set up endpoints
    iface_desc = interface->cur_altsetting;
    for (i = 0; i < iface_desc->desc.bNumEndpoints; i++) {
        endpoint = &iface_desc->endpoint[i].desc;
        
        // Check if there is no saved bulk in address and if the current endpoint is bulk in
        if (!dev->bulk_in_address && endpoint->bEndpointAddress == QUSB_EP_BULK_IN) {
            dev->bulk_in_length = endpoint->wMaxPacketSize;
            dev->bulk_in_address = endpoint->bEndpointAddress;
        }
        // Check if there is no saved bulk out address and if the endpoint is bulk out
        if (!dev->bulk_out_address && endpoint->bEndpointAddress == QUSB_EP_BULK_OUT) {
            dev->bulk_out_address = endpoint->bEndpointAddress;
        }
    }
    
    // Check if no bulk in or out addresses are found
    if (!(dev->bulk_in_address && dev->bulk_out_address)) {
        if (dev) {
            kref_put(&dev->ref, qusb_delete);
        }
        QUSB_PRINTK(("QuickUSB Error: No bulk endpoints found.\n"));
        return -EINVAL;
    }

    // Set QuickUSB device to interface
    usb_set_intfdata(interface, dev);

    // Register QuickUSB device
    result = usb_register_dev(interface, &qusb_class);
    if (result) {
        QUSB_PRINTK(("QuickUSB Error: Unable to register device.\n"));
        usb_set_intfdata(interface, NULL);
        if (dev != NULL) {
            kref_put(&dev->ref, qusb_delete);
        }
        return result;
    }
    else {
        QUSB_PRINTK(("QuickUSB: Registered a QuickUSB device\n"));
    }
    
    // Identify QuickUSB devices and increment counter
    if ((device_id->idVendor == VENDOR_ID) && (device_id->idProduct == PRODUCT_ID)) {
        num_qusb++;
    }

    return 0;
}



// Called by open()
static int qusb_open(struct inode *inode, struct file *filp) {
    struct qusb_dev *dev;
    struct usb_interface *interface;
    //int vaddr;

    // Get QuickUSB device
    interface = usb_find_interface(&qusb_driver, iminor(inode));
    dev = usb_get_intfdata(interface);
    
    // Set timeout
    dev->timeout = QUSB_DEFAULT_TIMEOUT;

    dev->bulk_in_buffer = kmalloc(QUSB_MAX_KMALLOC_SIZE, GFP_KERNEL);
    if (!dev->bulk_in_buffer) {
        QUSB_PRINTK(("QuickUSB Error: Out of memory.\n"));

        // Decrease reference count
        if (dev) {
            kref_put( &dev->ref, qusb_delete);
        }
        return -ENOMEM;
    }
    
    // Allocate kernel space buffer
    dev->buffer_ptr = kmalloc(QUSB_MAX_MMAP_SIZE + 2*PAGE_SIZE, GFP_KERNEL);
    if (dev->buffer_ptr == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Failed to allocate buffer.\n"));
        return -ENOMEM;
    }
    dev->buffer_area = (int *)(((unsigned long)dev->buffer_ptr + PAGE_SIZE - 1) & PAGE_MASK);
   
    // Save device pointer
    filp->private_data = dev;
    
    return 0;
}



// Called when the QuickUSB module is removed
static int qusb_release(struct inode *inode, struct file *filp) {
    struct qusb_dev *dev;
    //int vaddr;
    
	if (!filp || !(filp->private_data)) {
		return ENODEV;
	}

    // Get QuickUSB device
    dev = filp->private_data;
    
    // Free allocated memory
    if (dev->buffer_ptr) {
        kfree(dev->buffer_ptr);
        dev->buffer_ptr = NULL;
    }
    if (dev->bulk_in_buffer) {
        kfree(dev->bulk_in_buffer);
        dev->bulk_in_buffer = NULL;
    }

    filp->private_data = NULL;
    
    return 0;
}

#if defined(HAVE_COMPAT_IOCTL)
static long qusb_compat_ioctl(struct file *filp, unsigned int cmd, unsigned long arg) {
	// This function is called whenever a 32-bit process calls ioctl() on a 64-bit system
	//
	// Things to do:
	// 1. Acquire BKL, since kernel calls compat_ioctl without BKL.
	// 2. 32 to 64 bit conversion for long and pointer objects passed by user
	// 3. Process input data, get results.
	// 4. 64 to 32 bit conversion in order to pass the output data back to user
	// 5. Release BKL

	// Forward call to qusb_ioctl
	return qusb_ioctl(filp, cmd, compat_ptr(arg), 1);
}
#endif

// The main interface function to the library
#if defined(HAVE_UNLOCKED_IOCTL)
static long qusb_unlocked_ioctl(struct file *filp, unsigned int cmd, unsigned long arg) {
	// Forward call on to qusb_ioctl
	return qusb_ioctl(filp, cmd, (void __user *)arg, 0);
}
#else
static long qusb_locked_ioctl(struct inode *inode, struct file *filp, unsigned int cmd, unsigned long arg) {
	// Forward call on to qusb_ioctl
	return qusb_ioctl(filp, cmd, (void __user *)arg, 0);
}
#endif

static int qusb_ioctl(struct file *filp, unsigned int cmd, void __user *arg, BYTE compat) {
    struct qusb_dev *dev;
    QUSB_DRIVER_VERSION driver_version;
    QUSB_GET_STRING_DESCRIPTOR string_desc;
    QUSB_VENDOR_OR_CLASS_REQUEST_CONTROL vendor_or_class_req_ctrl;
    struct usb_device_descriptor device_descriptor;
    //struct QUSB_ASYNC qusb_async;
    QUSB_BULK_TRANSFER_CONTROL bulk_control;
    ULONG timeout;
    int result;
    
    result = 0;
    
    // Check type
    if ((_IOC_TYPE(cmd) != QUSB_IOCTL_INDEX)) {
        QUSB_PRINTK(("QuickUSB ioctl: Invalid command type.\n"));
        //return -ENOTTY;
    }
    
    // Verify arg address
    if (_IOC_DIR(cmd) & _IOC_READ) {
        result = !access_ok(VERIFY_WRITE, arg, _IOC_SIZE(cmd));
    }
    else if ( _IOC_DIR( cmd ) & _IOC_WRITE ) {
        result = !access_ok(VERIFY_READ, arg, _IOC_SIZE(cmd));
    }
    if (result) {
        QUSB_PRINTK(("QuickUSB ioctl: Invalid argument\n"));
        return -EFAULT;
    }
    
    // Get QuickUSB device
    dev = filp->private_data;
    
    // Interpret commands
    switch (cmd) {
        case IOCTL_QUSB_GET_DEVICE_DESCRIPTOR:
            QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_GET_DEVICE_DESCRIPTOR\n"));
            result = Qusb_GetDeviceDescriptor(filp, &device_descriptor);
            if (result < 0) {
                QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_GET_DEVICE_DESCRIPTOR failed!\n"));
                return result;
            }
            
            // Send data to user
            return copy_to_user(( void __user *)arg, &device_descriptor, sizeof(struct usb_device_descriptor));
            break;
            
        case IOCTL_QUSB_GET_STRING_DESCRIPTOR:
            QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_GET_STRING_DESCRIPTOR\n"));
            
            // Interpret arg
            result = copy_from_user(&string_desc, arg, sizeof(QUSB_GET_STRING_DESCRIPTOR));
            if (result != 0) {
                QUSB_PRINTK(("QuickUSB Error: Could not read user IOCTL data in get string descriptor.\n"));
                return result;
            }

            // Get string descriptor
            result = Qusb_GetStringDescriptor(filp, string_desc.Index, string_desc.Data, string_desc.Length);
            if (result < 0) {
                return result;
            }

            // Store bytes read
            string_desc.Length = result;
            
            // Send data to user
            return copy_to_user(arg, &string_desc, sizeof(QUSB_GET_STRING_DESCRIPTOR));
            break;
            
        case IOCTL_QUSB_BULK_READ:
            break;
            /*QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_BULK_READ\n"));
            // Interpret arg
            result = copy_from_user(&bulk_control, arg, sizeof(QUSB_BULK_TRANSFER_CONTROL));
            if (result != 0) {
                QUSB_PRINTK(("QuickUSB Error: Could not read user IOCTL data in bulk read.\n"));
                return result;
            }
            
            // Read bulk data
            result = Qusb_ReadWriteBulk(filp, 1, & bulk_control);
            if (result != 0) {
                QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_BULK_READ failed!\n"));
                return result;
            }
            
            // Send control to user
            return copy_to_user(arg, &bulk_control, sizeof(QUSB_BULK_TRANSFER_CONTROL));
            break;*/
         
        case IOCTL_QUSB_BULK_WRITE:
            QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_BULK_WRITE\n"));
            
            // Interpret arg
            result = copy_from_user(&bulk_control, arg, sizeof(QUSB_BULK_TRANSFER_CONTROL));
            if (result != 0) {
                QUSB_PRINTK(("QuickUSB Error: Could not read user IOCTL data in bulk write.\n"));
                return result;
            }
            
            // Wrtie bulk data
            result = Qusb_ReadWriteBulk(filp, 0, &bulk_control);
            if (result < 0) {
                QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_BULK_WRITE failed!\n"));
                return result;
            }
            
            // Send control to user
            return copy_to_user(arg, &bulk_control, sizeof(QUSB_BULK_TRANSFER_CONTROL));
            break;
            
        //case IOCTL_QUSB_VENDOR_OR_CLASS_REQUEST_IN:
        //case IOCTL_QUSB_VENDOR_OR_CLASS_REQUEST_OUT:
        case IOCTL_QUSB_VENDOR_OR_CLASS_REQUEST:
            QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_VENDOR_OR_CLASS_REQUEST\n"));

            // Interpret arg
            result = copy_from_user(&vendor_or_class_req_ctrl, arg, sizeof(QUSB_VENDOR_OR_CLASS_REQUEST_CONTROL));
            if (result != 0) {
                QUSB_PRINTK(("QuickUSB Error: Could not read user IOCTL data in vendor or class request.\n"));
                return result;
            }

            result = Qusb_VendorRequest(filp, &vendor_or_class_req_ctrl, compat);
            if (result < 0) {
                QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_VENDOR_OR_CLASS_REQUEST failed! (Error=0x%X)\n", -result));
                return result;
            }
            
            // Send data to user
            return copy_to_user(( void __user *)arg, &vendor_or_class_req_ctrl, sizeof(QUSB_VENDOR_OR_CLASS_REQUEST_CONTROL));
            break;
            
        case IOCTL_QUSB_GET_LAST_ERROR:
            QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_GET_LAST_ERROR\n"));
            return copy_to_user(arg, &driver_error, sizeof(QUSB_GET_DRIVER_ERROR));
            break;

        case IOCTL_QUSB_GET_DRIVER_VERSION:
            QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_GET_DRIVER_VERSION\n"));
            driver_version.MajorVersion = QUSB_DRIVER_MAJOR_VERSION;
            driver_version.MinorVersion = QUSB_DRIVER_MINOR_VERSION;
            driver_version.BuildVersion = QUSB_DRIVER_BUILD_VERSION;
            driver_version.QusbDriverNum = 0;
            
            // Send data to user
            return copy_to_user(arg, &driver_version, sizeof(QUSB_DRIVER_VERSION));
            break;
            
        case IOCTL_QUSB_SET_TIMEOUT:
            QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_SET_TIMEOUT\n"));

            // Interpret arg
            result = copy_from_user(&timeout , arg, sizeof(unsigned long));
            if (result != 0) {
                QUSB_PRINTK(("QuickUSB Error: Could not read user IOCTL data in set timeout.\n"));
                return result;
            }
            
            // Set timeout
            dev->timeout = timeout;
            
            return TRUE;
            break;
            
        case IOCTL_QUSB_ASYNC_BULK_READ:
            break;
            /*QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_ASYNC_BULK_READ\n"));
            
            // Interpret arg
            result = copy_from_user(&bulk_control, arg, sizeof(QUSB_BULK_TRANSFER_CONTROL));
            if (result != 0) {
                QUSB_PRINTK(("QuickUSB Error: Could not read user IOCTL data in async bulk read.\n"));
                return result;
            }
            
            // Read bulk data async
            result = Qusb_ReadWriteBulkAsync(filp, 1, &bulk_control);
            if (result < 0) {
                QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_ASYNC_BULK_READ failed!\n"));
                return result;
            }
            return copy_to_user(arg, &bulk_control, sizeof(QUSB_BULK_TRANSFER_CONTROL));
            break;*/
            
        case IOCTL_QUSB_ASYNC_BULK_WRITE:
            break;
            /*QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_ASYNC_BULK_WRITE\n"));

            // Interpret arg
            result = copy_from_user(&bulk_control, arg, sizeof(QUSB_BULK_TRANSFER_CONTROL));
            if ( result != 0 ) {
                QUSB_PRINTK(("QuickUSB Error: Could not read user IOCTL data in async bulk write.\n"));
                return result;
            }
            
            // Write bulk data async
            result = Qusb_ReadWriteBulkAsync(filp, 0, &bulk_control);
            if (result < 0) {
                QUSB_PRINTK(("QuickUSB ioctl: IOCTL_QUSB_ASYNC_BULK_WRITE failed!\n"));
                return result;
            }
            
            // Send data to user
            return copy_to_user(arg, &bulk_control, sizeof(QUSB_BULK_TRANSFER_CONTROL));
            break;*/
            
        case IOCTL_QUSB_ASYNC_WAIT:
            break;
            /*qusb_async.transaction = 0;
            qusb_async.immediate = 0;
            return copy_to_user(arg, &qusb_async, sizeof(QUSB_ASYNC));
            break;*/
            
        default:
            QUSB_PRINTK(("QuickUSB ioctl: Invalid command - %d..\n", cmd));
            //return -EINVAL;
            break;
    }
    
    return 0;
}



// File op - Read
static ssize_t qusb_read(struct file *file, char __user *buf, size_t count, loff_t *ppos) {
    int retval, bytes_read, totalBytesRead;
    struct qusb_dev *dev;
    ULONG readlen;
    size_t offset, blocksize;

    QUSB_PRINTK(("QuickUSB read\n"));
    
    // Get QuickUSB device
    dev = file->private_data;
    if (dev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid QuickUSB device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -EINVAL;
    }
    if (dev->udev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -EINVAL;
    }
    if (dev->bulk_in_buffer == NULL) {
        QUSB_PRINTK(("QuickUSB Error: bulk_in_buffer not initialized.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -EINVAL;
    }
    
    // First send the number of bytes to read
    readlen = (ULONG) count;
    retval = usb_control_msg(
        dev->udev,                     // Device
        usb_sndctrlpipe(dev->udev, 0), // Pipe
        0xB7,                          // Request
        64,                            // Request type
        0,                             // Value
        0,                             // Index
        &readlen,                      // Data
        sizeof(ULONG),                // Size
        dev->timeout);                 // Timeout

    // usb_control_msg returns 0 on success and a negative error value on failure
    if (retval < 0) {
        QUSB_PRINTK(("QuickUSB readlen failed: 0x%X\n", retval));
        return retval;
    }

    // Break the read into transfers no larger than QUSB_MAX_KMALLOC_SIZE in size
    offset = 0;
    totalBytesRead = 0;
    do {
        blocksize = (size_t) min(QUSB_MAX_KMALLOC_SIZE, (int)count - (int)offset);

        // Submit bulk request
        retval = usb_bulk_msg(
            dev->udev,                      // Device
            usb_rcvbulkpipe(dev->udev,
                dev->bulk_in_address),      // Pipe
            dev->bulk_in_buffer,            // Read buffer
            blocksize,                      // Bytes to read
            &bytes_read,                    // Bytes read
            dev->timeout);                  // Timeout


        // usb_bulk_msg returns 0 on success and a negative error value on failure
        if (retval < 0) {
            QUSB_PRINTK(("QuickUSB read failed: 0x%X\n", retval));
            return retval;
        }

        totalBytesRead += bytes_read;

        // copy_to_user returns the number of bytes that could not be copied
        if (copy_to_user(buf + offset, dev->bulk_in_buffer, bytes_read)) {
            QUSB_PRINTK(("QuickUSB copy failed\n"));
            return -EFAULT;
        }

        offset += blocksize;
    } while (offset < count); 

    return totalBytesRead;
}


/*static void qusb_write_callback(struct urb *urb) {
    //struct qusb_dev *dev = urb->context;

    QUSB_PRINTK(("Write completed with status: %d\n", (int)urb->status));

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,34)
    usb_buffer_free(urb->dev, urb->transfer_buffer_length, urb->transfer_buffer, urb->transfer_dma);
#else
    usb_free_coherent(urb->dev, urb->transfer_buffer_length, urb->transfer_buffer, urb->transfer_dma);
#endif
}*/

// File op - Write
static ssize_t qusb_write(struct file *file, const char __user *buf, size_t count, loff_t *ppos) {
    /*char *qusb_buf = NULL;
    struct urb *urb = NULL;
    struct qusb_dev *dev;

    QUSB_PRINTK(("Issuing write for %d bytes\n", (int)count));

    // Get QuickUSB device
    dev = file->private_data;
    
    urb = usb_alloc_urb(0, GFP_KERNEL);
    if (!urb) {
        QUSB_PRINTK(("Alloc failed\n"));
        return -ENOMEM;
    }

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,34)
    qusb_buf = usb_buffer_alloc(dev->udev, count, GFP_KERNEL, &urb->transfer_dma);
#else
    qusb_buf = usb_alloc_coherent(dev->udev, count, GFP_KERNEL, &urb->transfer_dma);
#endif
    if (copy_from_user(qusb_buf, buf, count)) {
        QUSB_PRINTK(("Copy failed\n"));
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,34)
        usb_buffer_free(dev->udev, count, qusb_buf, urb->transfer_dma);
#else
        usb_free_coherent(dev->udev, count, qusb_buf, urb->transfer_dma);
#endif
        usb_free_urb(urb);
        return -EFAULT;
    }

    usb_fill_bulk_urb(urb, dev->udev, usb_sndbulkpipe(dev->udev, dev->bulk_out_address), 
        qusb_buf, count, qusb_write_callback, dev);
    urb->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;
    usb_submit_urb(urb, GFP_KERNEL);
    usb_free_urb(urb);
    return(count);
*/
    int retval, bytes_written, totalBytesWritten;
    struct qusb_dev *dev;
    size_t offset, blocksize;

    QUSB_PRINTK(("QuickUSB write\n"));
 
    // Get QuickUSB device
    dev = file->private_data;
    if (dev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid QuickUSB device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -EINVAL;
    }
    if (dev->udev == NULL) {
        QUSB_PRINTK(("QuickUSB Error: Invalid device.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -EINVAL;
    }
    if (dev->bulk_in_buffer == NULL) {
        QUSB_PRINTK(("QuickUSB Error: bulk_in_buffer not initialized.\n"));
        driver_error.DriverError = DriverErrorInvalidParameter;
        return -EINVAL;
    }

    // Break the write into transfers no larger than QUSB_MAX_KMALLOC_SIZE in size
    offset = 0;
    totalBytesWritten = 0;
    do {
        blocksize = (size_t) min(QUSB_MAX_KMALLOC_SIZE, (int)count - (int)offset);
        QUSB_PRINTK(("Writing block of size: %d\n", (int)blocksize));

        // copy_to_user returns the number of bytes that could not be copied
        if (copy_from_user(dev->bulk_in_buffer, buf + offset, blocksize)) {
            QUSB_PRINTK(("QuickUSB copy failed\n"));
            return -EFAULT;
        }

        // Submit bulk request
        retval = usb_bulk_msg(
            dev->udev,                      // Device
            usb_sndbulkpipe(dev->udev,
                dev->bulk_out_address),     // Pipe
            dev->bulk_in_buffer,            // Write buffer
            blocksize,                      // Bytes to write
            &bytes_written,                 // Bytes written
            dev->timeout);                  // Timeout

        totalBytesWritten += bytes_written;
        QUSB_PRINTK(("Wrote %d bytes\n", (int)bytes_written));

        // usb_bulk_msg returns 0 on success and a negative error value on failure
        if (retval < 0) {
            QUSB_PRINTK(("QuickUSB write failed: 0x%X\n", retval));
            return retval;
        }

        offset += blocksize;
    } while (offset < count); 

    return totalBytesWritten;
}


/*#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,10) && !defined(tlb_vma)

void simple_vma_open(struct vm_area_struct *vma)
{
    QUSB_PRINTK(("Simple VMA open, virt %lx, phys %lx\n", vma->vm_start, vma->vm_pgoff << PAGE_SHIFT));
}

void simple_vma_close(struct vm_area_struct *vma)
{
    QUSB_PRINTK(("Simple VMA close\n"));
}

struct page * simple_vma_nopage(struct vm_area_struct *vma, unsigned long address, int *type)
{
    struct qusb_dev *dev = vma->vm_private_data;
    struct page * pageptr;
    unsigned long offset = vma->vm_pgoff << PAGE_SHIFT;
    unsigned long physaddr = dev->buffer_area;//address - vma->vm_start + offset;
    unsigned long pageframe = physaddr >> PAGE_SHIFT;

    QUSB_PRINTK(("INFO: %lx %lx %lx %lx %lx %lx\n", dev->buffer_area, offset, physaddr, address, pageframe, vma->vm_start));

    if (!pfn_valid(pageframe))
    {
        QUSB_PRINTK(("PFN NOT VALID\n"));
        return NOPAGE_SIGBUS;
    }
    pageptr = pfn_to_page(pageframe);
    get_page(pageptr);
    if (type)
        *type = VM_FAULT_MINOR;
    return pageptr;
}

static struct vm_operations_struct simple_nopage_vm_ops = {
    .open = simple_vma_open,
    .close = simple_vma_close,
    .nopage = simple_vma_nopage,
};

static int qusb_mmap(struct file *filp, struct vm_area_struct *vma) {
    unsigned long offset = vma->vm_pgoff << PAGE_SHIFT;

    QUSB_PRINTK(("NOPAGE MMAP\n"));

    if (offset >= __pa(high_memory) || (filp->f_flags & O_SYNC))
    {
        vma->vm_flags |= VM_IO;
    }
    vma->vm_flags |= VM_RESERVED;

    vma->vm_private_data = filp->private_data;
    vma->vm_ops = &simple_nopage_vm_ops;
    simple_vma_open(vma);
    return 0;
}

#else
*/

// This functions is called by the library for bulk transfers to get a valid user-space
// pointer to kernel memory
/*static int qusb_mmap(struct file *filp, struct vm_area_struct *vma) {
    struct qusb_dev *dev;
    ULONG offset, size;
    
    // Get QuickUSB device
    dev = filp->private_data;
    
    // Set offset and size
    offset = vma->vm_pgoff << PAGE_SHIFT;
    size = vma->vm_end - vma->vm_start;
    
    QUSB_PRINTK(("qusb_mmap: size=%d, offset=%d, kernal_adr=%p\n", (int)size, (int)offset, dev->buffer_area));

    // Check alignment
    if (offset & ~PAGE_MASK) {
        QUSB_PRINTK(("QuickUSB Error: Offset not aligned.\n"));
        return -1;
    }
    
    // Check size
    if (size > QUSB_MAX_MMAP_SIZE) {
        QUSB_PRINTK(("QuickUSB Error: Map size too large.\n"));
        return -1;
    }
    
    // Remap kernel space memory to user space
    if (remap_pfn_range(
            vma,                                        // Virtual memory area
            vma->vm_start,                                // Beginning user virtual address
            virt_to_phys(dev->buffer_area)>>PAGE_SHIFT,    // Page frame number
            size,                                        // Size
            vma->vm_page_prot)) {                        // Protection

        QUSB_PRINTK(("QuickUSB Error: Failed to remap memory.\n"));
        return -EAGAIN;
    }
    
    return 0;
}*/

//#endif


// Called when a module is disconnected from the computer
static void qusb_disconnect(struct usb_interface *interface) {
    struct qusb_dev *dev;
    QUSB_PRINTK(("QuickUSB disconnect\n"));
    lock_kernel();
    dev = usb_get_intfdata(interface);
    usb_set_intfdata(interface, NULL);
    usb_deregister_dev(interface, &qusb_class);
    dev->interface = NULL;
    unlock_kernel();
    kref_put(& dev->ref, qusb_delete); // Calling qusb_delete w/reference counting
}



// Called by qusb_disconnect
static void qusb_delete(struct kref * reference) {
    struct qusb_dev *dev;
    dev = container_of(reference, struct qusb_dev, ref);
	if (dev) {
        usb_put_dev(dev->udev);
        kfree (dev);
    }
}



/*static void qusb_read_bulk_callback(struct urb *urb) {
    if (urb->status &&
            !(urb->status == -ENOENT ||
            urb->status == -ECONNRESET ||
            urb->status == -ESHUTDOWN)) {
    }
}



static void qusb_write_bulk_callback(struct urb *urb) {
    if (urb->status &&
            !(urb->status == -ENOENT ||
            urb->status == -ECONNRESET ||
            urb->status == -ESHUTDOWN)) {
    }
}*/



// Called when driver is loaded (insmod)
static int __init qusb_init(void) {
    int result;
    
    QUSB_PRINTK(("QuickUSB driver initializing...\n" ));

    // Initialize number of QuickUSB and driver error
    num_qusb = 0;
    driver_error.UsbError = DriverErrorNone;
    driver_error.DriverError = DriverErrorNone;
    driver_error.DriverState = DriverErrorNone;
    
    // Register QuickUSB
    result = usb_register(&qusb_driver);
    if (result) {
        QUSB_PRINTK(("QuickUSB Error: [%d] Failed to register driver.\n", result));
    }
    QUSB_PRINTK(("%d QuickUSB modules found.\n", num_qusb));

    return result;
}
module_init(qusb_init);



// Called when driver is removed (rmmod)
static void __exit qusb_exit(void) {
    // Unregister QuickUSB
    usb_deregister(&qusb_driver);
    QUSB_PRINTK(("QuickUSB driver removed.\n"));
}
module_exit(qusb_exit);

