#!/bin/bash
QUSBLIBVERSION=2.15.0


#Welcome
echo "Bitwise Systems QuickUSB"
echo "This script will install the QuickUSB Library onto your computer"
echo ""

if [ $(id -u) != "0" ]; then
        echo "ERROR: You must be root for this script to work"
        exit 1
fi


#Create udev rule
if [ -d /etc/udev/rules.d ]; then
	cp Driver/90-qusb.rules /etc/udev/rules.d
else
	echo "ERROR: Unable to locate udev directory"
	exit
fi
cp Driver/qusb_script.sh /usr/local/bin/qusb_script.sh


#Remove old QuickUSB kernel object, if present
echo "NOTE: Removing currently installed quickusb kernel object"
echo "NOTE: (Disregard any 'Module qusb_lnx does not exist' errors"
rmmod qusb_lnx


#Build and install driver
if [ "`getconf LONG_BIT`" == "64" ]; then
	echo "NOTE: Building driver for 64-bit platform"
	cd Driver
	make install OUTDIR=x64
	cd ..
else
	echo "NOTE: Building driver for 32-bit platform"
	cd Driver
	make install OUTDIR=x86
	cd ..
fi


#Install library
if [ "`getconf LONG_BIT`" == "64" ]; then
	if [ ! -d /usr/lib32 ]; then
		echo "NOTE: Installing x64 library only (/usr/lib32 not found)"
		cp Library/x64/* /usr/lib
	else
		echo "NOTE: Installing x64 and x86 libraries"
		cp Library/x64/* /usr/lib

		cp Library/x86/* /usr/lib32
		ln -fs /usr/lib32/libquickusb.a.$QUSBLIBVERSION /usr/lib32/libquickusb.a
		ln -fs /usr/lib32/libquickusb.so.$QUSBLIBVERSION /usr/lib32/libquickusb.so
	fi
else
	echo "NOTE: Installing x86 library"
	cp Library/x86/* /usr/lib
fi
ln -fs /usr/lib/libquickusb.so.$QUSBLIBVERSION /usr/lib/libquickusb.so
ln -fs /usr/lib/libquickusb.a.$QUSBLIBVERSION /usr/lib/libquickusb.a
/sbin/ldconfig


echo ""
echo "NOTE: Installation complete"
echo ""
