#ifndef	VERSION_INCLUDED
#define	VERSION_INCLUDED

//////////////////////////////////////////////////////////////////////
//
// File:      version.h
// $Archive: /Projects/Bitwise/QuickUSB/Library/Driver/Version.h $
//
// Purpose:
//    Version information header file for EZ-USB General Purpose Driver
//
// Environment:
//    kernel mode
//
// $Author: Blake Henry $
//
//  
// Copyright (c) 1997 Anchor Chips, Inc.  May not be reproduced without
// permission.  See the license agreement for more details.
//
//////////////////////////////////////////////////////////////////////

//
// Make sure to keep these in sync with the version
// information in ezusbsys.rc
//
#define QUSB_DRIVER_MAJOR_VERSION	2
#define QUSB_DRIVER_MINOR_VERSION	15
#define QUSB_DRIVER_BUILD_VERSION	0

#endif	//	VERSION_INCLUDED

